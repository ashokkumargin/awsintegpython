
def getDBConfig():
	dbconfig = {
	  "host": "awsmysql-1.c66v1kaibbzi.us-east-1.rds.amazonaws.com",
	  "port": "3001",
	  "user": "awsmysql",
	  "passwd": "awsmysql",
	  "database": "awsmysql"
	}
	return dbconfig
